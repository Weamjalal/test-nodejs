require('../helper')
require('../../lib/example')
// Unit test for an example model go here
